    <div class="sidebar-wrapper">
            <div class="logo"><a href="#"><img src="../images/logo.png"></a></div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="create.php">
                        <i class="ti-user"></i>
                        <p>Create Contract</p>
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="ti-cloud-up"></i>
                        <p>Upload</p>
                    </a>
                </li>
                <li>
                    <a href="services.php">
                        <i class="ti-check-box"></i>
                        <p>Select Services</p>
                    </a>
                </li>
                <li>
                    <a href="../login.html">
                        <i class="ti-power-off"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </div>